using QueueingSystems;
using Xunit;

public class QueueingAnalyticsTests
{
    [Fact]
    public void Mm1k_K5_ReturnsExpectedBlockingProbability()
    {
        var result = QueueingAnalytics.Mm1k(0.8, 1.0, 5);
        Assert.InRange(result.Blocking, 0.0887, 0.0889);
    }

    [Fact]
    public void Mmmk_ThreeServers_ReducesBlockingProbability()
    {
        var result = QueueingAnalytics.Mmmk(2.4, 1.0, 3, 13);
        Assert.InRange(result.Blocking, 0.0146, 0.0149);
    }
}
