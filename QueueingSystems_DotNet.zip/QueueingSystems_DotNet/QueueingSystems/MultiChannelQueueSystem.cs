using System.Threading;
using System.Threading.Channels;

namespace QueueingSystems;

// Асинхронна реалізація producer-consumer на основі System.Threading.Channels.
// maxQueue — місткість буфера очікування; канали обслуговування працюють паралельно.
public sealed class MultiChannelQueueSystem
{
    private readonly Channel<Customer> queue;
    private readonly int channelsCount;
    private int accepted;
    private int rejected;
    private int served;

    public int Accepted => Volatile.Read(ref accepted);
    public int Rejected => Volatile.Read(ref rejected);
    public int Served => Volatile.Read(ref served);

    public MultiChannelQueueSystem(int channelsCount, int maxQueue)
    {
        if (channelsCount <= 0)
            throw new ArgumentOutOfRangeException(nameof(channelsCount));
        if (maxQueue <= 0)
            throw new ArgumentOutOfRangeException(nameof(maxQueue));

        this.channelsCount = channelsCount;
        queue = Channel.CreateBounded<Customer>(
            new BoundedChannelOptions(maxQueue)
            {
                // Wait + TryWrite дає змогу зафіксувати відмову,
                // коли буфер уже заповнений.
                FullMode = BoundedChannelFullMode.Wait,
                SingleWriter = false,
                SingleReader = false
            });
    }

    public bool Add(Customer customer)
    {
        ArgumentNullException.ThrowIfNull(customer);

        if (queue.Writer.TryWrite(customer))
        {
            Interlocked.Increment(ref accepted);
            return true;
        }

        Interlocked.Increment(ref rejected);
        return false;
    }

    public async Task StartAsync(CancellationToken token = default)
    {
        Task[] workers = new Task[channelsCount];

        for (int i = 0; i < channelsCount; i++)
        {
            workers[i] = Task.Run(async () =>
            {
                await foreach (Customer customer in queue.Reader.ReadAllAsync(token))
                {
                    int delay = Math.Max(0, (int)Math.Ceiling(customer.ServiceTime * 1000));
                    await Task.Delay(delay, token);
                    Interlocked.Increment(ref served);
                }
            }, token);
        }

        await Task.WhenAll(workers);
    }

    public void Complete() => queue.Writer.TryComplete();
}
