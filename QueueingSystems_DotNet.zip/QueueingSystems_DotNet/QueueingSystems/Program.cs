using System;
using System.Collections.Generic;
using System.Linq;

namespace QueueingSystems;

public sealed class Customer
{
    public int Id { get; }
    public double ArrivalTime { get; }
    public double ServiceTime { get; init; }
    public double? ServiceStartTime { get; set; }

    public Customer(int id, double arrivalTime, double serviceTime = 0)
    {
        Id = id;
        ArrivalTime = arrivalTime;
        ServiceTime = serviceTime;
    }
}

public sealed class ServiceChannel
{
    public int Id { get; }
    public bool IsBusy { get; private set; }

    public ServiceChannel(int id) => Id = id;

    public void Start() => IsBusy = true;
    public void Complete() => IsBusy = false;
}

public static class RandomVariates
{
    // Експоненційна випадкова величина з параметром rate.
    public static double Exponential(Random random, double rate)
    {
        ArgumentNullException.ThrowIfNull(random);
        if (rate <= 0) throw new ArgumentOutOfRangeException(nameof(rate));

        double u;
        do { u = random.NextDouble(); } while (u <= 0.0);
        return -Math.Log(u) / rate;
    }
}

public sealed record SimulationResult(
    int Servers,
    int SystemCapacity,
    long Arrivals,
    long Accepted,
    long Rejected,
    long Served,
    double RejectionProbability,
    double EffectiveArrivalRate,
    double AverageNumberInSystem,
    double AverageQueueLength,
    double AverageWaitingTime,
    double Utilization);

public static class QueueingAnalytics
{
    // Аналітичні характеристики M/M/1/K.
    public static (double Blocking, double Throughput, double L) Mm1k(
        double lambda, double mu, int capacity)
    {
        Validate(lambda, mu, capacity);
        double rho = lambda / mu;
        double[] p = new double[capacity + 1];

        if (Math.Abs(rho - 1.0) < 1e-12)
        {
            Array.Fill(p, 1.0 / (capacity + 1));
        }
        else
        {
            double p0 = (1.0 - rho) / (1.0 - Math.Pow(rho, capacity + 1));
            for (int n = 0; n <= capacity; n++)
                p[n] = p0 * Math.Pow(rho, n);
        }

        double l = p.Select((value, n) => value * n).Sum();
        double blocking = p[capacity];
        return (blocking, lambda * (1.0 - blocking), l);
    }

    // Аналітичні характеристики M/M/m/K, де capacity = m + Qmax.
    public static (double Blocking, double EffectiveRate, double L,
                   double Lq, double Wq, double Utilization) Mmmk(
        double lambda, double mu, int servers, int capacity)
    {
        if (lambda <= 0) throw new ArgumentOutOfRangeException(nameof(lambda));
        if (mu <= 0) throw new ArgumentOutOfRangeException(nameof(mu));
        if (servers <= 0) throw new ArgumentOutOfRangeException(nameof(servers));
        if (capacity < servers) throw new ArgumentOutOfRangeException(nameof(capacity));

        var weights = new double[capacity + 1];
        weights[0] = 1.0;

        for (int n = 1; n <= capacity; n++)
        {
            double serviceRate = Math.Min(n, servers) * mu;
            weights[n] = weights[n - 1] * lambda / serviceRate;
        }

        double sum = weights.Sum();
        var probabilities = weights.Select(w => w / sum).ToArray();
        double blocking = probabilities[capacity];
        double effective = lambda * (1.0 - blocking);
        double l = probabilities.Select((p, n) => p * n).Sum();
        double lq = probabilities.Select((p, n) => p * Math.Max(0, n - servers)).Sum();
        double wq = effective > 0 ? lq / effective : 0.0;
        double utilization = effective / (servers * mu);

        return (blocking, effective, l, lq, wq, utilization);
    }

    private static void Validate(double lambda, double mu, int capacity)
    {
        if (lambda <= 0) throw new ArgumentOutOfRangeException(nameof(lambda));
        if (mu <= 0) throw new ArgumentOutOfRangeException(nameof(mu));
        if (capacity <= 0) throw new ArgumentOutOfRangeException(nameof(capacity));
    }
}

public sealed class QueueingSimulator
{
    // Подієва симуляція M/M/m/K. capacity — загальна місткість системи,
    // тобто кількість заявок у черзі плюс заявки на обслуговуванні.
    public SimulationResult Run(double lambda, double mu, int servers,
        int queueCapacity, int numberOfArrivals, int seed = 42)
    {
        if (lambda <= 0 || mu <= 0) throw new ArgumentOutOfRangeException();
        if (servers <= 0 || queueCapacity < 0 || numberOfArrivals <= 0)
            throw new ArgumentOutOfRangeException();

        int capacity = servers + queueCapacity;
        var random = new Random(seed);
        var waiting = new Queue<Customer>();
        var departures = new PriorityQueue<double, double>();

        long accepted = 0, rejected = 0, served = 0;
        double now = 0, nextArrival = RandomVariates.Exponential(random, lambda);
        double areaSystem = 0, areaQueue = 0, busyArea = 0;
        double lastEvent = 0, totalWait = 0;
        int inSystem = 0, busy = 0;

        void UpdateAreas(double time)
        {
            double dt = time - lastEvent;
            areaSystem += inSystem * dt;
            areaQueue += Math.Max(0, inSystem - servers) * dt;
            busyArea += busy * dt;
            lastEvent = time;
        }

        for (int i = 1; i <= numberOfArrivals; i++)
        {
            now = nextArrival;

            // Обробляємо всі завершення обслуговування до наступного надходження.
            while (departures.TryPeek(out double departureTime, out _) &&
                   departureTime <= now)
            {
                UpdateAreas(departureTime);
                departures.Dequeue();
                inSystem--;
                busy--;
                served++;

                if (waiting.Count > 0)
                {
                    Customer next = waiting.Dequeue();
                    next.ServiceStartTime = departureTime;
                    totalWait += departureTime - next.ArrivalTime;
                    busy++;
                    double completion = departureTime +
                        RandomVariates.Exponential(random, mu);
                    departures.Enqueue(completion, completion);
                    inSystem++;
                }
            }

            UpdateAreas(now);
            var customer = new Customer(i, now);

            if (inSystem >= capacity)
            {
                rejected++;
            }
            else
            {
                accepted++;
                inSystem++;

                if (busy < servers)
                {
                    customer.ServiceStartTime = now;
                    busy++;
                    double completion = now + RandomVariates.Exponential(random, mu);
                    departures.Enqueue(completion, completion);
                }
                else
                {
                    waiting.Enqueue(customer);
                }
            }

            nextArrival = now + RandomVariates.Exponential(random, lambda);
        }

        // Доводимо обслуговування прийнятих заявок до завершення,
        // щоб коректно обчислити кількість обслужених і часові середні.
        while (departures.TryDequeue(out double departure, out _))
        {
            UpdateAreas(departure);
            inSystem--;
            busy--;
            served++;

            if (waiting.Count > 0)
            {
                Customer next = waiting.Dequeue();
                totalWait += departure - next.ArrivalTime;
                busy++;
                double completion = departure + RandomVariates.Exponential(random, mu);
                departures.Enqueue(completion, completion);
                inSystem++;
            }
        }

        double observationTime = lastEvent;
        double effectiveRate = observationTime > 0 ? accepted / observationTime : 0;
        double averageWait = served > 0 ? totalWait / served : 0;

        return new SimulationResult(
            servers, capacity, numberOfArrivals, accepted, rejected, served,
            (double)rejected / numberOfArrivals,
            effectiveRate,
            observationTime > 0 ? areaSystem / observationTime : 0,
            observationTime > 0 ? areaQueue / observationTime : 0,
            averageWait,
            observationTime > 0 ? busyArea / (servers * observationTime) : 0);
    }
}

internal static class Program
{
    private static void Main()
    {
        const double lambda = 2.4;
        const double mu = 1.0;
        const int queueCapacity = 10;
        const int arrivals = 500_000;

        Console.WriteLine("M/M/m/K: імітаційне та аналітичне дослідження");
        Console.WriteLine("m | Pвідм (аналіт.) | Pвідм (імітац.) | Wq (аналіт.)");

        var simulator = new QueueingSimulator();

        for (int m = 1; m <= 5; m++)
        {
            int totalCapacity = m + queueCapacity;
            var analytical = QueueingAnalytics.Mmmk(
                lambda, mu, m, totalCapacity);

            var simulated = simulator.Run(
                lambda, mu, m, queueCapacity, arrivals, seed: 42 + m);

            Console.WriteLine(
                $"{m} | {analytical.Blocking:F5} | " +
                $"{simulated.RejectionProbability:F5} | {analytical.Wq:F4}");
        }

        Console.WriteLine();
        Console.WriteLine("M/M/1/K: аналітичні результати для λ=0.8, μ=1.0");
        foreach (int k in new[] { 2, 3, 5, 7, 10 })
        {
            var result = QueueingAnalytics.Mm1k(0.8, 1.0, k);
            Console.WriteLine(
                $"K={k}: Pвідм={result.Blocking:F4}; " +
                $"λеф={result.Throughput:F4}; L={result.L:F4}");
        }
    }
}
