# Моделювання СМО M/M/1/K та M/M/m/K на C#/.NET 8

## Склад проєкту
- `Customer` — заявка та часові характеристики.
- `ServiceChannel` — стан окремого каналу обслуговування.
- `RandomVariates.Exponential()` — генерація експоненційних інтервалів.
- `QueueingAnalytics` — аналітичні характеристики M/M/1/K і M/M/m/K.
- `QueueingSimulator` — подієва імітація багатоканальної СМО з обмеженою місткістю.
- `MultiChannelQueueSystem` — асинхронна реалізація producer–consumer із `System.Threading.Channels` та паралельними робітниками.
- `QueueingAnalyticsTests` — приклади модульних тестів xUnit.

## Запуск
Потрібен .NET 8 SDK.

```bash
dotnet run --project QueueingSystems/QueueingSystems.csproj
dotnet test QueueingSystems.Tests/QueueingSystems.Tests.csproj
```

## Важливі уточнення щодо моделі
1. Для M/M/1/K параметр `K` — загальна кількість заявок у системі, включно із заявкою на обслуговуванні.
2. Для M/M/m/K у цьому проєкті `queueCapacity` — місткість саме черги, а загальна місткість `K = m + Qmax`.
3. У фрагменті одноканального коду з рукопису час обслуговування генерувався, але не впливав на стан сервера. У зведеній версії додано подієве моделювання, яке враховує надходження та завершення обслуговування.
4. Для порівняння з аналітичними результатами слід запускати достатню кількість подій і повторювати експеримент із різними початковими значеннями генератора випадкових чисел. Імітаційні оцінки не зобов'язані точно збігатися з теоретичними через статистичну похибку.
5. У початковому багатоканальному фрагменті статті використовувався `BoundedChannelFullMode.DropWrite`. У зведеному класі встановлено `BoundedChannelFullMode.Wait` разом із `TryWrite`, щоб невдалий запис можна було трактувати як відмову через заповнений буфер.

## Офіційні джерела
1. Microsoft Learn. **Queue<T> Class** — https://learn.microsoft.com/en-us/dotnet/api/system.collections.generic.queue-1
2. Microsoft Learn. **System.Threading.Channels** — https://learn.microsoft.com/en-us/dotnet/core/extensions/channels
3. Microsoft Learn. **Channel.CreateBounded<T> Method** — https://learn.microsoft.com/en-us/dotnet/api/system.threading.channels.channel.createbounded
4. Microsoft Learn. **Interlocked Class** — https://learn.microsoft.com/en-us/dotnet/api/system.threading.interlocked
5. Microsoft Learn. **Task Class** — https://learn.microsoft.com/en-us/dotnet/api/system.threading.tasks.task
6. Microsoft Learn. **PriorityQueue<TElement,TPriority> Class** — https://learn.microsoft.com/en-us/dotnet/api/system.collections.generic.priorityqueue-2
7. xUnit. **Getting Started** — https://xunit.net/docs/getting-started/v2/dotnet-core

Посилання наведено на документацію технологій і бібліотек, використаних у програмній реалізації. Це не означає, що сама математична модель M/M/1/K або M/M/m/K є розробкою Microsoft.
